# MyStore Luffy 40 - no custom ProGuard rules required for the first build.
